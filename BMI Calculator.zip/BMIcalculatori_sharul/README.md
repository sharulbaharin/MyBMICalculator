# BMIcalculatorinAndroidStudio
This BMI Calculator in android studio using java in Android studio
Some of the output screens

![image](https://user-images.githubusercontent.com/64765400/119442448-b75bb600-bcdc-11eb-8e58-aa9a5c00b4c1.png)
![image](https://user-images.githubusercontent.com/64765400/119442460-bb87d380-bcdc-11eb-9c62-a291afccc355.png)
![image](https://user-images.githubusercontent.com/64765400/119442467-be82c400-bcdc-11eb-974a-de62c3ac9cfb.png)
![image](https://user-images.githubusercontent.com/64765400/119442473-c2164b00-bcdc-11eb-8176-7fc6dbe60345.png)

